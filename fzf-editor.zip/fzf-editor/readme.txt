=== Plugin Name ===
Contributors: markjaquith, mdawaffe
Donate link: http://khromov-wm.ru
Tags: 404, error, seo
Requires at least: 2.0.2
Tested up to: 2.1
Stable tag: 4.3

This plugin add new option in you blog for use in 404 page. This is 

== Description ==

If you often change the template to your blog - then this plugin is for you.
Sometimes it is very important to keep the text error page.
Since some of these texts are large and change them do not feel like every time - you can save the text in the database. And only then retrieve it from there. And I will help you with this ...

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `fzf-editor` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php get_option('err404'); ?>` in your 404.php file.

== Frequently Asked Questions ==

= How do I find the configuration page for the plugin? =

It is located at the bottom of the section "Settings"

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, `/tags/4.3/screenshot-1.png` (or jpg, jpeg, gif)
2. This is the second screen shot

== Changelog ==

= 1.0 =
* New plugin is created!

== Arbitrary section ==

You may provide arbitrary sections, in the same format as the ones above.  This may be of use for extremely complicated
plugins where more information needs to be conveyed that doesn't fit into the categories of "description" or
"installation."  Arbitrary sections will be shown below the built-in sections outlined above.