<?php
/*
Plugin Name: 404Manager
Plugin URI: http://khromov-wm.ru/404Manager.html
Description: Fast-Edit you current template and create error pages(404)
Version: 1.0
Author: Ivan Khromov
Author URI: http://khromov-wm.ru

*/
add_action('admin_menu', 'my_plugin_menu');

function my_plugin_menu() {

  add_options_page('404Manager', 'Менеджер 404', 'manage_options', 'error-page-fzf', 'my_plugin_options');

}
function my_plugin_options() {

  if (!current_user_can('manage_options'))  {
    wp_die( __('You do not have sufficient permissions to access this page.') );
  }
?>
<div id="wrapper">
<h2>Редактирование страницы 404.</h2>
<p><b>Страница ошибки</b> - важная часть Вашего сайта! Главное - уметь их верно составлять! Ведь как поведет себя пользователь, увидев подобного рода ошибку - неизвестно. Важно рассчитать все до мельчайших деталей. Этот плагин поможет Вам автоматизировать процесс создания, при этом уменьшит код в шаблоне. При смене шаблона можно просто вставить эту строчку, и она заменит весь код. Никаких копирайтов, ссылок не будет, убедитесь в этом сами!<br />Если у Вас есть пожелания или замечания, всегда рад видеть Вас на своем <a href="http://khromov-wm.ru" target="_blank">сайте</a>.</p>
	<p><h4>Внимание!</h4>
		Для работы плагина необходимо сделать следующее:
		<br>Вставить строку:<br><code>&lt;?php<br>
			get_option('err404');<br>
			?&gt;
			</code>
			<br>При этом заметьте! <i>PHP код не исполняется! Весь код PHP редактируется прямо в шаблоне!</i>
			<p class="submit">
<a href="theme-editor.php?file=/themes/<?php echo get_template(); ?>/404.php&theme=<?php echo get_current_theme(); ?>&dir=theme" class="button" target="_blank">Вот тут(ссылка прямо на Ваш шаблон)</a>
			</p>
	</p>
	<h2>Редактирование</h2>
	<form action="options.php" method="post" name="mainform">
		<?php wp_nonce_field('update-options'); ?>
		<input type="hidden" name="action" value="update" />
		<input type="hidden" name="page_options" value="err404" />
		
	<table width="100%" class="form-table">
		<tr valign="center">
			<th>404.php(файл не найден)<br>
			<small>Эта ошибка возникает, когда посетитель обращается к не существующей странице сайта. Важно дать ему возможность вернуться назад. 
			<br>Самое распространенное: используйте <code>javascript:history.go(-1);</code> для возврата его на предыдущую страницу.
			<br>Для большей уверенности, используйте ссылку на главную страницу.
			</small>	
		</th>
		</tr>
		<tr>
			<td><textarea name="err404" style="width: 100%; height:340px;"><?php echo get_option('err404'); ?></textarea></td>
		</tr>
	</table>
	<p class="submit">
	<input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>"  name="saveall"/>
	</p>
	</form>
	</div>
<?php
}

?>